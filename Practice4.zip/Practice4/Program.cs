﻿using System;

namespace Practice4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("A = ");
            double a = double.Parse(Console.ReadLine());
            Console.WriteLine("B = ");
            double b = double.Parse(Console.ReadLine());
            Console.WriteLine("C = ");
            double c = double.Parse(Console.ReadLine());
            Console.WriteLine("D = ");
            double d = double.Parse(Console.ReadLine());
            Console.WriteLine("((a^3 * /b - c*d)^2) / a + b + c");
            double v = Math.Pow(a, 3) * (Math.Sqrt(b - c * d));
            Console.WriteLine("v = " + v);
            double y = Math.Pow(v, 2) / (a + b + c);
            Console.WriteLine("y = " + y);
            Console.ReadKey();
        }
    }
}
